const express = require("express");
const router = express.Router();
const data = require("../data");
const goalData = data.goals;
const userData = data.users;